import React from 'react';
import Card from '../components/Card.jsx';
import Hero from '../components/Hero.jsx';

const coaches = [
  { name: "María Camila Solorza", role: "Especialista en comunicación y escenarios", bio: "10+ años formando líderes y profesionales. Sello: exigencia amable." },
  { name: "Coach Invitado", role: "Storytelling / Keynotes", bio: "Experto en estructura narrativa para charlas de alto impacto." },
  { name: "Voz & Dicción", role: "Vocal Health", bio: "Técnicas de respiración, proyección y dicción para escenarios exigentes." }
];

export default function Coaches() {
  return (
    <>
      <Hero title="Coaches" kicker="Mentores y especialistas"
        ctaPrimary={<a href="/contact" className="btn btn-primary">Agenda una llamada</a>}
      >
        Acompañamiento cercano con estándares altos y feedback accionable en cada sesión.
      </Hero>

      <section className="container-v3 py-14">
        <div className="grid gap-6 md:grid-cols-3">
          {coaches.map((c, i) => (
            <Card key={i} title={c.name} subtitle={c.role}>
              {c.bio}
            </Card>
          ))}
        </div>
      </section>
    </>
  );
}
