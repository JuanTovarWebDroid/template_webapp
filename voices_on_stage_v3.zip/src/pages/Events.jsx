import React from 'react';
import Card from '../components/Card.jsx';
import Hero from '../components/Hero.jsx';

const events = [
  { title: "Voices on Stage 2025", date: "Octubre 2025", place: "Gold Coast — Presencial + Streaming", desc: "Cierre del programa con ponencias en vivo." },
  { title: "Masterclass de Storytelling", date: "Próxima fecha", place: "Online", desc: "Estructura tu charla y aprende a cautivar audiencias." },
  { title: "Taller Voz & Presencia", date: "Próxima fecha", place: "Híbrido", desc: "Dicción, respiración, proyección y lenguaje corporal." }
];

export default function Events() {
  return (
    <>
      <Hero title="Eventos" kicker="Próximas fechas"
        ctaPrimary={<a href="/contact" className="btn btn-primary">Quiero participar</a>}
      >
        Experiencias en vivo para practicar, recibir feedback y conectar con comunidad.
      </Hero>

      <section className="container-v3 py-14">
        <div className="grid gap-6 md:grid-cols-3">
          {events.map((e, i) => (
            <Card key={i} title={e.title} subtitle={`${e.date} · ${e.place}`} ctaLabel="Reservar cupo">
              {e.desc}
            </Card>
          ))}
        </div>
      </section>
    </>
  );
}
