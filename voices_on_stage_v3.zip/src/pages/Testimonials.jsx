import React from 'react';
import Card from '../components/Card.jsx';
import Hero from '../components/Hero.jsx';

const testimonials = [
  { name: "Ana P.", text: "Pasé de temer al escenario a disfrutarlo. La práctica semanal y el feedback marcaron la diferencia.", meta: "Ingeniera · Sydney" },
  { name: "Daniel R.", text: "Descubrí que mi historia puede inspirar y aprendí a contarla sin miedo.", meta: "Founder · Melbourne" },
  { name: "Sofía G.", text: "El evento final fue inolvidable. Me sentí en un TEDx y ahora doy charlas en mi empresa.", meta: "HR Manager · Brisbane" },
];

export default function Testimonials() {
  return (
    <>
      <Hero title="Testimonios" kicker="Historias reales" />
      <section className="container-v3 py-14">
        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <Card key={i} title={t.name} subtitle={t.meta}>{t.text}</Card>
          ))}
        </div>
      </section>
    </>
  );
}
