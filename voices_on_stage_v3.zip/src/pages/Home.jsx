import React from 'react';
import Hero from '../components/Hero.jsx';
import Card from '../components/Card.jsx';

export default function Home() {
  return (
    <>
      <Hero
        title="Tu voz merece un escenario."
        kicker="Edición V3 · Orange + Gold"
        ctaPrimary={<a href="/programs" className="btn btn-primary">Ver Programa</a>}
        ctaSecondary={<a href="/events" className="btn btn-outline">Próximos Eventos</a>}
      >
        Un programa premium de 10 semanas para comunicar con seguridad, autenticidad y liderazgo. Cierra con un evento en escenario real estilo TED.
      </Hero>

      <section className="container-v3 py-14">
        <div className="grid gap-6 md:grid-cols-3">
          <Card title="Coaching 1:1" subtitle="Entrenamiento personalizado">
            Sesiones privadas enfocadas en objetivos concretos: storytelling, voz, presencia, dicción, pánico escénico.
          </Card>
          <Card title="Workshops para equipos" subtitle="Empresas & organizaciones">
            Talleres prácticos para mejorar presentaciones, liderazgo y comunicación efectiva con clientes y equipos.
          </Card>
          <Card title="Evento final" subtitle="Voices on Stage">
            Presenta tu charla en un escenario profesional con curaduría y producción — el cierre perfecto del programa.
          </Card>
        </div>
      </section>
    </>
  );
}
