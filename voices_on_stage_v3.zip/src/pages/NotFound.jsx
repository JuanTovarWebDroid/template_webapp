import React from 'react';

export default function NotFound() {
  return (
    <div className="container-v3 py-24 text-center">
      <h1 className="text-5xl font-bold">404</h1>
      <p className="text-white/60 mt-2">Página no encontrada</p>
      <a href="/" className="btn btn-outline mt-6">Volver al inicio</a>
    </div>
  );
}
