import React, { useState } from 'react';
import Hero from '../components/Hero.jsx';

export default function Contact() {
  const [sent, setSent] = useState(false);
  const onSubmit = (e) => {
    e.preventDefault();
    setTimeout(() => setSent(true), 600);
  };

  return (
    <>
      <Hero title="Contacto" kicker="Hablemos">
        Agenda una llamada o envíanos tus objetivos para recomendarte el mejor camino.
      </Hero>

      <section className="container-v3 py-14">
        <form onSubmit={onSubmit} className="grid gap-4 md:grid-cols-2 card p-6">
          <input required placeholder="Nombre completo" className="rounded-xl border border-white/10 bg-black/40 px-3 py-2" />
          <input type="email" required placeholder="Email" className="rounded-xl border border-white/10 bg-black/40 px-3 py-2" />
          <input placeholder="Ciudad" className="rounded-xl border border-white/10 bg-black/40 px-3 py-2" />
          <select className="rounded-xl border border-white/10 bg-black/40 px-3 py-2">
            <option>Superar miedo escénico</option>
            <option>Charla profesional</option>
            <option>Storytelling y liderazgo</option>
            <option>Voz y dicción</option>
          </select>
          <textarea rows="4" placeholder="¿Qué te gustaría lograr en 10 semanas?" className="md:col-span-2 rounded-xl border border-white/10 bg-black/40 px-3 py-2"></textarea>
          <div className="md:col-span-2 flex items-center gap-3">
            <button className="btn btn-primary">Enviar</button>
            <span className="text-sm text-white/60">Cupos limitados · Programa premium</span>
          </div>
          {sent && <div className="md:col-span-2 text-sm rounded-xl border border-green-400/30 bg-green-400/10 px-3 py-2 text-green-200">¡Gracias! Te contactaremos pronto.</div>}
        </form>
      </section>
    </>
  );
}
