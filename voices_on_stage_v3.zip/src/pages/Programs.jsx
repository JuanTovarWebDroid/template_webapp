import React from 'react';
import Card from '../components/Card.jsx';
import Hero from '../components/Hero.jsx';
import { CheckCircle2 } from 'lucide-react';

const modules = [
  { title: "Voz y presencia", desc: "Respiración, proyección, dicción y manejo del cuerpo." },
  { title: "Storytelling", desc: "Estructura, claridad y narrativa memorable." },
  { title: "Pánico a poder", desc: "Estrategias para el miedo escénico y manejo de nervios." },
  { title: "Diseño de charla", desc: "Construcción de mensaje, slides y ritmo." },
  { title: "Ensayos guiados", desc: "Prácticas con feedback accionable." },
  { title: "Evento final", desc: "Presentación en escenario real." }
];

export default function Programs() {
  return (
    <>
      <Hero title="Programa 10 semanas" kicker="Transformación guiada"
        ctaPrimary={<a href="/contact" className="btn btn-primary">Aplicar ahora</a>}
        ctaSecondary={<a href="/coaches" className="btn btn-outline">Conoce a los coaches</a>}
      >
        Entrenamiento premium con acompañamiento cercano y prácticas reales. Diseñado para resultados medibles en 10 semanas.
      </Hero>

      <section className="container-v3 py-14">
        <div className="grid gap-6 md:grid-cols-3">
          {modules.map((m, i) => (
            <div key={i} className="card p-6">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-brand-gold" />
                <div>
                  <div className="font-semibold">{m.title}</div>
                  <p className="mt-1 text-sm text-white/70">{m.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
