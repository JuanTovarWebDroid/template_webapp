import React from 'react';
import Card from '../components/Card.jsx';
import Hero from '../components/Hero.jsx';

const posts = [
  { title: "Cómo calmar los nervios antes de hablar", excerpt: "Técnicas rápidas de respiración y foco." },
  { title: "Estructura de una charla memorable", excerpt: "Inicio potente, historia central y cierre con acción." },
  { title: "Voz saludable para escenarios", excerpt: "Hábitos diarios para cuidar tu voz." }
];

export default function Blog() {
  return (
    <>
      <Hero title="Blog" kicker="Consejos prácticos" />
      <section className="container-v3 py-14">
        <div className="grid gap-6 md:grid-cols-3">
          {posts.map((p, i) => (
            <Card key={i} title={p.title}>{p.excerpt}</Card>
          ))}
        </div>
      </section>
    </>
  );
}
