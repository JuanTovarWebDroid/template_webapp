import React from 'react';
import { motion } from 'framer-motion';

export default function Hero({ title, kicker, children, ctaPrimary, ctaSecondary }) {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 opacity-60 pointer-events-none">
        <div className="absolute -top-24 -left-24 h-80 w-80 rounded-full bg-brand-orange/20 blur-3xl" />
        <div className="absolute -bottom-24 -right-24 h-96 w-96 rounded-full bg-brand-gold/20 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(800px_500px_at_50%_-10%,rgba(255,215,0,0.12),transparent)]" />
      </div>
      <div className="container-v3 py-20 md:py-28 text-center">
        {kicker && <motion.div initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} className="pill mb-4">{kicker}</motion.div>}
        <motion.h1 initial={{opacity:0, y:16}} animate={{opacity:1, y:0}} className="text-4xl md:text-6xl font-bold">
          <span className="bg-gradient-to-b from-white via-white to-white/50 bg-clip-text text-transparent">{title}</span>
        </motion.h1>
        {children && <motion.p initial={{opacity:0, y:16}} animate={{opacity:1, y:0}} className="mt-4 max-w-2xl mx-auto text-lg text-white/70">{children}</motion.p>}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          {ctaPrimary}
          {ctaSecondary}
        </div>
      </div>
    </section>
  );
}
