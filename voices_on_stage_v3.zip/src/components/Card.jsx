import React from 'react';

export default function Card({ title, subtitle, children, ctaLabel, onCta, href, footer }) {
  const Wrapper = href ? 'a' : 'div';
  const extra = href ? {href} : {};
  return (
    <Wrapper className="card p-6 hover:shadow-ring transition" {...extra}>
      {title && <h3 className="text-lg font-semibold">{title}</h3>}
      {subtitle && <p className="text-sm text-white/60 mt-1">{subtitle}</p>}
      <div className="mt-4 text-white/80">{children}</div>
      <div className="mt-6 flex items-center justify-between">
        {ctaLabel && <button onClick={onCta} className="btn btn-outline">{ctaLabel}</button>}
        {footer}
      </div>
    </Wrapper>
  );
}
