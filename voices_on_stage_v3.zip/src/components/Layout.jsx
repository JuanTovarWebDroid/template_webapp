import React from 'react';
import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { Mic } from 'lucide-react';

function NavItem({ to, children }) {
  return (
    <NavLink
      to={to}
      className={({isActive}) =>
        `px-3 py-1.5 rounded-lg transition ${isActive ? 'text-white' : 'text-white/75 hover:text-white'}`
      }
      end
    >
      {children}
    </NavLink>
  );
}

export default function Layout() {
  const location = useLocation();
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 border-b border-white/10 bg-black/40 backdrop-blur">
        <div className="container-v3 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-brand-orange to-brand-gold text-black flex items-center justify-center">
              <Mic className="h-4 w-4" />
            </div>
            <span className="font-semibold tracking-wide text-white/90">VOICES ON STAGE</span>
            <span className="pill ml-2 hidden md:inline-flex">V3</span>
          </div>
          <nav className="hidden md:flex items-center gap-2 text-sm">
            <NavItem to="/">Inicio</NavItem>
            <NavItem to="/programs">Programa</NavItem>
            <NavItem to="/coaches">Coaches</NavItem>
            <NavItem to="/events">Eventos</NavItem>
            <NavItem to="/testimonials">Testimonios</NavItem>
            <NavItem to="/blog">Blog</NavItem>
            <NavItem to="/contact">Contacto</NavItem>
          </nav>
          <a href="/contact" className="btn btn-primary hidden md:inline-flex">Inscríbete</a>
        </div>
      </header>

      <main className="flex-1">
        <Outlet key={location.pathname} />
      </main>

      <footer className="border-t border-white/10 bg-black/30 backdrop-blur py-10">
        <div className="container-v3 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-sm text-white/60">© {new Date().getFullYear()} Voices on Stage</div>
          <div className="text-sm text-white/50">Inspira. Comunica. Transforma.</div>
        </div>
      </footer>
    </div>
  );
}
