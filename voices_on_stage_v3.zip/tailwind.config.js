/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          bg: "#0A0B12",
          surface: "#11131c",
          surface2: "#0f1018",
          orange: "#FF6A00",
          gold: "#FFD700",
          text: "#FFFFFF",
          muted: "#AAB1C6"
        }
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(255,255,255,0.06), 0 10px 30px rgba(0,0,0,0.5)",
        ring: "0 0 0 2px rgba(255,215,0,0.25)"
      },
      borderRadius: {
        xl2: "1.25rem"
      }
    },
  },
  plugins: [],
};
