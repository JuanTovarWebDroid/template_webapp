# Voices On Stage v3 (React + Vite + Tailwind + React Router)

Dark VIP style with orange/gold accents. Multi-page routing and card-based UI.

## Run locally
```bash
npm install
npm run dev
```

## Pages
- `/` Home
- `/programs` Programs (10-week course)
- `/coaches` Coaches
- `/events` Events
- `/testimonials` Testimonials
- `/blog` Blog
- `/contact` Contact
