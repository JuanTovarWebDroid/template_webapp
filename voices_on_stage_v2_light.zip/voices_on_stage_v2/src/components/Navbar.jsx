import React from 'react';
import { Mic } from 'lucide-react';

const links = [
  { id: 'home', label: 'Inicio' },
  { id: 'programa', label: 'Programa' },
  { id: 'servicios', label: 'Servicios' },
  { id: 'logros', label: 'Logros' },
  { id: 'testimonios', label: 'Testimonios' },
  { id: 'evento', label: 'Evento' },
  { id: 'faq', label: 'FAQ' },
  { id: 'contacto', label: 'Contacto' },
];

export default function Navbar() {
  const handleScroll = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/40 backdrop-blur">
      <div className="container h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-vos-orange to-vos-gold text-black flex items-center justify-center">
            <Mic className="h-4 w-4" />
          </div>
          <span className="font-semibold tracking-wide text-white/90">VOICES ON STAGE</span>
          <span className="hidden md:inline-block text-xs px-2 py-0.5 rounded-full bg-white/10 border border-white/10 ml-2">Edición 2.0</span>
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm">
          {links.map(l => (
            <button key={l.id} onClick={() => handleScroll(l.id)} className="text-white/75 hover:text-white">
              {l.label}
            </button>
          ))}
        </nav>
        <button onClick={() => handleScroll('contacto')} className="hidden md:inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-vos-orange to-vos-gold px-4 py-2 font-semibold text-black shadow">
          Inscríbete
        </button>
      </div>
    </header>
  );
}
