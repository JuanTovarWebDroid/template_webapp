import React, { useState } from 'react';

function Item({q, a}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-3xl p-6 bg-vos-card border border-white/10">
      <button className="w-full text-left flex items-center justify-between" onClick={() => setOpen(!open)}>
        <span className="font-medium text-white/90">{q}</span>
        <span className={`transition ${open ? 'rotate-180' : ''}`}>⌄</span>
      </button>
      {open && <p className="mt-3 text-sm text-white/70">{a}</p>}
    </div>
  );
}

export default function FAQ() {
  const items = [
    { q: "¿Necesito experiencia previa?", a: "No. Empezamos desde tu punto actual y diseñamos un plan que te lleve al escenario con confianza." },
    { q: "¿Qué incluye el curso?", a: "10 semanas de formación, ensayos guiados, coaching premium y tu presentación final." },
    { q: "¿Puedo tomarlo desde otra ciudad?", a: "Sí. Formato híbrido con sesiones online y práctica presencial opcional." },
    { q: "¿Cuántos cupos hay?", a: "Grupo reducido para asegurar acompañamiento cercano." }
  ];
  return (
    <section id="faq" className="section">
      <div className="container grid gap-4 md:grid-cols-2">
        {items.map((it, i) => <Item key={i} {...it} />)}
      </div>
    </section>
  );
}
