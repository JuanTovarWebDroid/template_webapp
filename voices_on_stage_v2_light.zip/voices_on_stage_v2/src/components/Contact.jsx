import React, { useState } from 'react';

export default function Contact() {
  const [sent, setSent] = useState(false);
  const onSubmit = (e) => {
    e.preventDefault();
    setTimeout(() => setSent(true), 600);
  };

  return (
    <section id="contacto" className="section">
      <div className="container">
        <h2 className="text-3xl md:text-4xl font-semibold mb-8">Contacto</h2>
        <div className="rounded-3xl p-6 bg-vos-card border border-white/10">
          <form onSubmit={onSubmit} className="grid gap-4 md:grid-cols-2">
            <input required placeholder="Nombre completo" className="rounded-xl border border-white/10 bg-black/40 px-3 py-2" />
            <input type="email" required placeholder="Email" className="rounded-xl border border-white/10 bg-black/40 px-3 py-2" />
            <input placeholder="Ciudad" className="rounded-xl border border-white/10 bg-black/40 px-3 py-2" />
            <select className="rounded-xl border border-white/10 bg-black/40 px-3 py-2">
              <option>Superar miedo escénico</option>
              <option>Dar una charla profesional</option>
              <option>Storytelling y liderazgo</option>
              <option>Mejorar mi voz y dicción</option>
            </select>
            <textarea rows="4" placeholder="¿Qué te gustaría lograr en 10 semanas?" className="md:col-span-2 rounded-xl border border-white/10 bg-black/40 px-3 py-2"></textarea>
            <div className="md:col-span-2 flex items-center gap-3">
              <button className="rounded-2xl bg-gradient-to-r from-vos-orange to-vos-gold px-6 py-3 font-semibold text-black">Enviar</button>
              <span className="text-sm text-white/60">Cupos limitados · Programa premium</span>
            </div>
            {sent && <div className="md:col-span-2 text-sm rounded-xl border border-green-400/30 bg-green-400/10 px-3 py-2 text-green-200">¡Gracias! Te contactaremos pronto.</div>}
          </form>
        </div>
      </div>
    </section>
  );
}
