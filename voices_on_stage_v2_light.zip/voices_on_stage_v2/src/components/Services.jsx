import React from 'react';
import { Mic, Users, Star } from 'lucide-react';

export default function Services() {
  return (
    <section id="servicios" className="section">
      <div className="container">
        <h2 className="text-3xl md:text-4xl font-semibold mb-8">Formación a tu medida</h2>
        <div className="grid gap-6 md:grid-cols-3">
          <div className="rounded-3xl p-6 bg-vos-card border border-white/10">
            <div className="flex items-center gap-3">
              <Star className="h-5 w-5 text-vos-gold" />
              <h3 className="font-semibold">Curso Voices on Stage (10 semanas)</h3>
            </div>
            <p className="mt-2 text-sm text-white/70">Entrenamiento premium con prácticas reales, feedback y acompañamiento cercano.</p>
          </div>
          <div className="rounded-3xl p-6 bg-vos-card border border-white/10">
            <div className="flex items-center gap-3">
              <Users className="h-5 w-5 text-vos-gold" />
              <h3 className="font-semibold">Coaching personalizado</h3>
            </div>
            <p className="mt-2 text-sm text-white/70">Mentoría 1:1 en liderazgo, mentalidad y performance para potenciar tu voz.</p>
          </div>
          <div className="rounded-3xl p-6 bg-vos-card border border-white/10">
            <div className="flex items-center gap-3">
              <Mic className="h-5 w-5 text-vos-gold" />
              <h3 className="font-semibold">Workshops corporativos</h3>
            </div>
            <p className="mt-2 text-sm text-white/70">Comunicación para equipos: presentaciones, reuniones y ventas.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
