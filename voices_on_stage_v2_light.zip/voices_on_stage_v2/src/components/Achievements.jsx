import React from 'react';

export default function Achievements() {
  return (
    <section id="logros" className="section">
      <div className="container grid gap-6 md:grid-cols-3">
        <div className="rounded-3xl p-6 bg-vos-card border border-white/10 text-center">
          <div className="text-4xl font-bold">150+</div>
          <div className="text-white/60">Personas formadas</div>
        </div>
        <div className="rounded-3xl p-6 bg-vos-card border border-white/10 text-center">
          <div className="text-4xl font-bold">4</div>
          <div className="text-white/60">Ciudades en Australia</div>
        </div>
        <div className="rounded-3xl p-6 bg-vos-card border border-white/10 text-center">
          <div className="text-4xl font-bold">98%</div>
          <div className="text-white/60">Satisfacción</div>
        </div>
      </div>
    </section>
  );
}
