import React from 'react';
import Navbar from './components/Navbar.jsx';
import Hero from './components/Hero.jsx';
import Program from './components/Program.jsx';
import Services from './components/Services.jsx';
import Achievements from './components/Achievements.jsx';
import Testimonials from './components/Testimonials.jsx';
import Event from './components/Event.jsx';
import FAQ from './components/FAQ.jsx';
import Contact from './components/Contact.jsx';
import Footer from './components/Footer.jsx';

export default function App() {
  return (
    <div className="min-h-screen bg-vos-bg">
      <Navbar />
      <main>
        <Hero />
        <Program />
        <Services />
        <Achievements />
        <Testimonials />
        <Event />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
