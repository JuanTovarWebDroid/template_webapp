import React from 'react';
import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section id="home" className="section relative overflow-hidden">
      <div className="absolute inset-0 -z-10 opacity-60 pointer-events-none">
        <div className="absolute -top-24 -left-24 h-80 w-80 rounded-full bg-vos-orange/20 blur-3xl" />
        <div className="absolute -bottom-24 -right-24 h-96 w-96 rounded-full bg-vos-gold/20 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(800px_500px_at_50%_-10%,rgba(255,215,0,0.12),transparent)]" />
      </div>
      <div className="container text-center">
        <motion.div initial={{opacity:0, y:16}} animate={{opacity:1, y:0}} transition={{duration:.6}} className="mb-4">
          <span className="inline-flex items-center gap-2 text-xs rounded-full border border-white/10 bg-white/5 px-3 py-1 text-white/70">Edición 2.0</span>
        </motion.div>
        <motion.h1 initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{duration:.7, delay:.1}} className="text-4xl md:text-6xl font-bold">
          <span className="bg-gradient-to-b from-white via-white to-white/50 bg-clip-text text-transparent">
            Tu voz merece un escenario.
          </span>
        </motion.h1>
        <motion.p initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{duration:.7, delay:.2}} className="mt-4 max-w-2xl mx-auto text-lg text-white/70">
          Un programa premium de 10 semanas para comunicar con seguridad, autenticidad y liderazgo. Cierre en escenario real tipo TED.
        </motion.p>
        <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{duration:.7, delay:.3}} className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <a href="#programa" className="rounded-2xl border border-white/15 bg-white/5 px-6 py-3 font-semibold text-white/90">Ver programa</a>
          <a href="#contacto" className="rounded-2xl bg-gradient-to-r from-vos-orange to-vos-gold px-6 py-3 font-semibold text-black">Reservar mi lugar</a>
        </motion.div>
      </div>
    </section>
  );
}
