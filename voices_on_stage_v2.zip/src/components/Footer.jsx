import React from 'react';

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-white/10 bg-black/40 backdrop-blur py-10">
      <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-sm text-white/60">© {year} Voices on Stage. Todos los derechos reservados.</div>
        <div className="text-sm text-white/50">Inspira. Comunica. Transforma.</div>
      </div>
    </footer>
  );
}
