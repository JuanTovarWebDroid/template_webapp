import React from 'react';

const items = [
  { quote: "Pasé de temer al escenario a disfrutarlo. La práctica semanal y el feedback marcaron la diferencia.", name: "Ana P.", role: "Ingeniera", city: "Sydney" },
  { quote: "Descubrí que mi historia puede inspirar y aprendí a contarla sin miedo.", name: "Daniel R.", role: "Founder", city: "Melbourne" },
  { quote: "El evento final fue inolvidable. Me sentí en un TEDx y ahora doy charlas en mi empresa.", name: "Sofía G.", role: "HR Manager", city: "Brisbane" },
];

export default function Testimonials() {
  return (
    <section id="testimonios" className="section">
      <div className="container">
        <h2 className="text-3xl md:text-4xl font-semibold mb-8">Lo que dicen</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {items.map((t, i) => (
            <div key={i} className="rounded-3xl p-6 bg-vos-card border border-white/10">
              <p className="text-white/80">“{t.quote}”</p>
              <div className="mt-6 text-sm text-white/60">{t.name} · {t.role} · {t.city}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
