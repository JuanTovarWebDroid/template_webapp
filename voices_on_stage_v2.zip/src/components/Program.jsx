import React from 'react';
import { CheckCircle2 } from 'lucide-react';

const items = [
  { title: "Voz y presencia", desc: "Respiración, proyección, dicción y manejo del cuerpo." },
  { title: "Storytelling", desc: "Estructura, claridad de ideas y narrativa memorable." },
  { title: "Pánico a poder", desc: "Estrategias para el miedo escénico y manejo de nervios." },
  { title: "Diseño de charla", desc: "Mensaje, slides esenciales y ritmo." },
  { title: "Ensayos guiados", desc: "Prácticas con feedback accionable todas las semanas." },
  { title: "Evento final", desc: "Presentación en Voices on Stage frente a público real." }
];

export default function Program() {
  return (
    <section id="programa" className="section">
      <div className="container">
        <h2 className="text-3xl md:text-4xl font-semibold mb-8">Voices on Stage: transformación guiada</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {items.map((i, idx) => (
            <div key={idx} className="rounded-3xl p-6 bg-vos-card border border-white/10">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-vos-gold" />
                <div>
                  <div className="font-semibold">{i.title}</div>
                  <p className="mt-1 text-sm text-white/70">{i.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
