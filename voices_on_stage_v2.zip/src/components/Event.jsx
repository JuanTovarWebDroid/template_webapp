import React from 'react';

export default function Event() {
  return (
    <section id="evento" className="section">
      <div className="container">
        <h2 className="text-3xl md:text-4xl font-semibold mb-4">Evento tipo TED: tu momento</h2>
        <div className="rounded-3xl p-6 bg-vos-card border border-white/10">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2 text-white/80">
              <div>🗓 Octubre 2025</div>
              <div>📍 Gold Coast · Presencial + Streaming</div>
              <div>👥 10 ponentes (cupos actuales)</div>
            </div>
            <p className="md:col-span-2 text-white/70">
              Un escenario profesional, curaduría de charlas y producción cuidada. Tu charla será el resultado de 10 semanas de trabajo estratégico.
            </p>
          </div>
          <div className="mt-6">
            <a href="#contacto" className="inline-block rounded-2xl bg-gradient-to-r from-vos-orange to-vos-gold px-5 py-2.5 font-semibold text-black">Quiero estar en el escenario</a>
          </div>
        </div>
      </div>
    </section>
  );
}
