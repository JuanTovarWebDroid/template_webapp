/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        vos: {
          bg: "#0B0B12",
          card: "#11121a",
          orange: "#FF6A00",
          gold: "#FFD700"
        }
      }
    },
  },
  plugins: [],
};
