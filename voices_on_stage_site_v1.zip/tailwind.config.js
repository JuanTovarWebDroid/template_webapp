/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./main.jsx",
    "./VoicesOnStage.jsx",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
